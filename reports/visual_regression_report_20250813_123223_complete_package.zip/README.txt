Visual AI Regression Analysis Package
Generated: 2025-08-13 12:32:23

CONTENTS:
=========

Reports:
- visual_regression_report_20250813_123223.pdf - Pdf report
- visual_regression_report_20250813_123223.json - Json report
- visual_regression_report_20250813_123223_visual_comparison.png - Visual report
- visual_regression_report_20250813_123223_side_by_side.png - Sidebyside report
- visual_regression_report_20250813_123223_difference_heatmap.png - Heatmap report

Test Configuration:
==================
- Reference URL: https://ultimateqa.com/automation
- Test URL: https://thinking-tester-contact-list.herokuapp.com/
- Browser: chrome
- Resolution: 1920x1080
- Layout Analysis: Enabled
- Color Analysis: Enabled
- AI Analysis: Enabled
- WCAG Analysis: Enabled

Results Summary:
===============
- Overall Similarity: 80.93%
- Layout Differences: 85
- Color Changes: 209
- Missing Elements: 38
- New Elements: 54

How to Use:
===========
1. Extract all files to a folder
2. Open the HTML report in your web browser
3. View the PDF report for printing/sharing
4. Use the JSON file for data integration
5. Image files show visual comparisons and differences

For detailed analysis, start with the HTML report which includes



interactive features and comprehensive results.
