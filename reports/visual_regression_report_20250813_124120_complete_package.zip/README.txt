Visual AI Regression Analysis Package
Generated: 2025-08-13 12:41:21

CONTENTS:
=========

Reports:
- visual_regression_report_20250813_124120.pdf - Pdf report
- visual_regression_report_20250813_124120.json - Json report
- visual_regression_report_20250813_124120_visual_comparison.png - Visual report
- visual_regression_report_20250813_124120_side_by_side.png - Sidebyside report
- visual_regression_report_20250813_124120_difference_heatmap.png - Heatmap report

Test Configuration:
==================
- Reference URL: https://httpbin.org/html
- Test URL: https://httpbin.org/html
- Browser: chrome
- Resolution: 1280x720
- Layout Analysis: Enabled
- Color Analysis: Enabled
- AI Analysis: Disabled
- WCAG Analysis: Disabled

Results Summary:
===============
- Overall Similarity: 100.00%
- Layout Differences: 0
- Color Changes: 0
- Missing Elements: 0
- New Elements: 0

How to Use:
===========
1. Extract all files to a folder
2. Open the HTML report in your web browser
3. View the PDF report for printing/sharing
4. Use the JSON file for data integration
5. Image files show visual comparisons and differences

For detailed analysis, start with the HTML report which includes



interactive features and comprehensive results.
