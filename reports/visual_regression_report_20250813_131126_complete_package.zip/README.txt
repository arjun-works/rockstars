Visual AI Regression Analysis Package
Generated: 2025-08-13 13:11:27

CONTENTS:
=========

Reports:
- visual_regression_report_20250813_131126.pdf - Pdf report
- visual_regression_report_20250813_131126.json - Json report
- visual_regression_report_20250813_131126_visual_comparison.png - Visual report
- visual_regression_report_20250813_131126_side_by_side.png - Sidebyside report
- visual_regression_report_20250813_131126_difference_heatmap.png - Heatmap report

Test Configuration:
==================
- Reference URL: https://example.com
- Test URL: https://example.com
- Browser: chrome
- Resolution: 1920x1080
- Layout Analysis: Enabled
- Color Analysis: Enabled
- AI Analysis: Enabled
- WCAG Analysis: Enabled

Results Summary:
===============
- Overall Similarity: 100.00%
- Layout Differences: 0
- Color Changes: 0
- Missing Elements: 0
- New Elements: 0

How to Use:
===========
1. Extract all files to a folder
2. Open the HTML report in your web browser
3. View the PDF report for printing/sharing
4. Use the JSON file for data integration
5. Image files show visual comparisons and differences

For detailed analysis, start with the HTML report which includes



interactive features and comprehensive results.
