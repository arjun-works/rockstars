Visual AI Regression Analysis Package
Generated: 2025-08-13 14:07:08

CONTENTS:
=========

Reports:
- visual_regression_report_20250813_140708.pdf - Pdf report
- visual_regression_report_20250813_140708.json - Json report
- visual_regression_report_20250813_140708_visual_comparison.png - Visual report
- visual_regression_report_20250813_140708_side_by_side.png - Sidebyside report
- visual_regression_report_20250813_140708_difference_heatmap.png - Heatmap report

Test Configuration:
==================
- Reference URL: https://thinking-tester-contact-list.herokuapp.com/
- Test URL: https://example.com
- Browser: chrome
- Resolution: 1920x1080
- Layout Analysis: Enabled
- Color Analysis: Enabled
- AI Analysis: Enabled
- WCAG Analysis: Enabled

Results Summary:
===============
- Overall Similarity: 94.69%
- Layout Differences: 26
- Color Changes: 84
- Missing Elements: 28
- New Elements: 55

How to Use:
===========
1. Extract all files to a folder
2. Open the HTML report in your web browser
3. View the PDF report for printing/sharing
4. Use the JSON file for data integration
5. Image files show visual comparisons and differences

For detailed analysis, start with the HTML report which includes



interactive features and comprehensive results.
